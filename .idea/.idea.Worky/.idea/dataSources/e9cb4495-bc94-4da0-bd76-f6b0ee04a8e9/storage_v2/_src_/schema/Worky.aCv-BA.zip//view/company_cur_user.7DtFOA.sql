create definer = mac@localhost view company_cur_user as
select `worky`.`company`.`id`           AS `id`,
       `worky`.`company`.`name`         AS `name`,
       `worky`.`company`.`email`        AS `email`,
       `worky`.`company`.`phoneNumber`  AS `phoneNumber`,
       `worky`.`company`.`office_coord` AS `office_coord`,
       `worky`.`company`.`createdBy`    AS `createdBy`,
       `worky`.`company`.`website`      AS `website`
from `worky`.`company`
where `worky`.`company`.`createdBy` = substring_index(user(), '@', 1);

grant delete, insert, select, update on table company_cur_user to company_role@'''''';

