create definer = mac@localhost view worker_cur_user as
select `worky`.`worker`.`id`          AS `id`,
       `worky`.`worker`.`second_name` AS `second_name`,
       `worky`.`worker`.`first_name`  AS `first_name`,
       `worky`.`worker`.`surname`     AS `surname`,
       `worky`.`worker`.`age`         AS `age`,
       `worky`.`worker`.`phoneNumber` AS `phoneNumber`,
       `worky`.`worker`.`email`       AS `email`,
       `worky`.`worker`.`createdBy`   AS `createdBy`
from `worky`.`worker`
where `worky`.`worker`.`createdBy` = substring_index(user(), '@', 1);

grant delete, insert, select, update on table worker_cur_user to worker_role@'''''';

