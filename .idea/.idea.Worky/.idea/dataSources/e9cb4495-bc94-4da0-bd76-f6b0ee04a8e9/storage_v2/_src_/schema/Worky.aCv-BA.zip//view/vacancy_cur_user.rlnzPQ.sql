create definer = mac@localhost view vacancy_cur_user as
select `worky`.`vacancy`.`id`           AS `id`,
       `worky`.`vacancy`.`company_id`   AS `company_id`,
       `worky`.`vacancy`.`post`         AS `post`,
       `worky`.`vacancy`.`min_salary`   AS `min_salary`,
       `worky`.`vacancy`.`education_id` AS `education_id`,
       `worky`.`vacancy`.`experience`   AS `experience`,
       `worky`.`vacancy`.`description`  AS `description`,
       `worky`.`vacancy`.`income_date`  AS `income_date`,
       `worky`.`vacancy`.`max_salary`   AS `max_salary`,
       `worky`.`vacancy`.`createdBy`    AS `createdBy`
from `worky`.`vacancy`
where `worky`.`vacancy`.`createdBy` = substring_index(user(), '@', 1);

grant delete, insert, select, update on table vacancy_cur_user to worker_role@'''''';

grant delete, insert, select, update on table vacancy_cur_user to company_role@'''''';

