create definer = mac@localhost view aspnetusers_cur_user as
select `worky`.`aspnetusers`.`Id`                   AS `Id`,
       `worky`.`aspnetusers`.`UserName`             AS `UserName`,
       `worky`.`aspnetusers`.`NormalizedUserName`   AS `NormalizedUserName`,
       `worky`.`aspnetusers`.`Email`                AS `Email`,
       `worky`.`aspnetusers`.`NormalizedEmail`      AS `NormalizedEmail`,
       `worky`.`aspnetusers`.`EmailConfirmed`       AS `EmailConfirmed`,
       `worky`.`aspnetusers`.`PasswordHash`         AS `PasswordHash`,
       `worky`.`aspnetusers`.`SecurityStamp`        AS `SecurityStamp`,
       `worky`.`aspnetusers`.`ConcurrencyStamp`     AS `ConcurrencyStamp`,
       `worky`.`aspnetusers`.`PhoneNumber`          AS `PhoneNumber`,
       `worky`.`aspnetusers`.`PhoneNumberConfirmed` AS `PhoneNumberConfirmed`,
       `worky`.`aspnetusers`.`TwoFactorEnabled`     AS `TwoFactorEnabled`,
       `worky`.`aspnetusers`.`LockoutEnd`           AS `LockoutEnd`,
       `worky`.`aspnetusers`.`LockoutEnabled`       AS `LockoutEnabled`,
       `worky`.`aspnetusers`.`AccessFailedCount`    AS `AccessFailedCount`,
       `worky`.`aspnetusers`.`image`                AS `image`
from `worky`.`aspnetusers`
where `worky`.`aspnetusers`.`UserName` = substring_index(user(), '@', 1);

grant delete, insert, select, update on table aspnetusers_cur_user to worker_role@'''''';

grant delete, insert, select, update on table aspnetusers_cur_user to company_role@'''''';

