create definer = mac@localhost view feedback_cur_user as
select `worky`.`feedback`.`id`         AS `id`,
       `worky`.`feedback`.`resume_id`  AS `resume_id`,
       `worky`.`feedback`.`vacancy_id` AS `vacancy_id`,
       `worky`.`feedback`.`status`     AS `status`,
       `worky`.`feedback`.`createdBy1` AS `createdBy1`,
       `worky`.`feedback`.`createdBy2` AS `createdBy2`
from `worky`.`feedback`
where `worky`.`feedback`.`createdBy1` = substring_index(user(), '@', 1)
   or `worky`.`feedback`.`createdBy2` = substring_index(user(), '@', 1);

grant delete, insert, select, update on table feedback_cur_user to company_role@'''''';

grant delete, insert, select, update on table feedback_cur_user to worker_role@'''''';

