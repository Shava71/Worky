create definer = mac@localhost view resume_cur_user as
select `worky`.`resume`.`id`           AS `id`,
       `worky`.`resume`.`worker_id`    AS `worker_id`,
       `worky`.`resume`.`skill`        AS `skill`,
       `worky`.`resume`.`city`         AS `city`,
       `worky`.`resume`.`experience`   AS `experience`,
       `worky`.`resume`.`education_id` AS `education_id`,
       `worky`.`resume`.`income_date`  AS `income_date`,
       `worky`.`resume`.`wantedSalary` AS `wantedSalary`,
       `worky`.`resume`.`post`         AS `post`,
       `worky`.`resume`.`createdBy`    AS `createdBy`
from `worky`.`resume`
where `worky`.`resume`.`createdBy` = substring_index(user(), '@', 1);

grant delete, insert, select, update on table resume_cur_user to worker_role@'''''';

